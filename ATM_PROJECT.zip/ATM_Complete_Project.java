package Projects;
import java.util.*;

public class ATM_Complete_Project {

	public static void main(String[] args) {
		
		int pin = 1234;
		int balance = 10000;
		
		int AddAmount = 0;
		int TakeAmount = 0;
	
		String name;
		
		Scanner sc=new Scanner(System.in);
		
		// we have to take an input by an user
		
		System.out.println("Enter your pin number ");
		
		int password = sc.nextInt();
		
		if(password==pin)
		{
			System.out.println("Enter your name ");
			name = sc.next();
			System.out.println();
			System.out.println("Welcome " + name);
			System.out.println();
			
			while (true)
			{
				System.out.println("Press 1 to check your balance ");
				System.out.println("Press 2 to add amount ");
				System.out.println("Press 3 to take amount ");
				System.out.println("Press 4 to take receipt ");
				System.out.println("Press 5 to EXIT ");
				
				int opt = sc.nextInt();
				
				switch (opt)
				{
				
				case 1:
					System.out.println("YOUR CURRENT BALANCE IS " + balance);
					break;
				case 2:
					System.out.println("HOW MUCH AMOUNT DID YOU WANT TO ADD TO YOUR ACCOUNT ");
					AddAmount = sc.nextInt();
					System.out.println("Successfully Credited ");
					balance = AddAmount + balance;
					//10000 = 100 + 10000
					//balance = 10100
					break;
				case 3:
					System.out.println("HOW MUCH AMOUNT DID YOU WANT TO TAKE \n");
					TakeAmount = sc.nextInt();
					if(TakeAmount>balance) 
					{
						System.out.println("Your balance is Insufficient");
						System.out.println("Try less than your available balance");
					}
					else
					{
						System.out.println("Successfully Taken\n");
						balance = balance - TakeAmount;
						//balance = 10100 = 10100 - 100
						//balance = 10000
					}
					break;
				case 4:
					System.out.println("WELCOME TO ALL IN ONE MINI ATM \n ");
					System.out.println("Available balance is " + balance);
					System.out.println("Amount deposited  " + AddAmount);
					System.out.println("Amount Taken  " + TakeAmount);
					System.out.println("Thanks for your Coming");
					break;	
					}
				
				if(opt == 5)
				{
					System.out.println("THANK YOU");
					break;
				}

			}
		}
		else 
		{
			System.out.println("Wrong Pin Number");
		}

	}

}
